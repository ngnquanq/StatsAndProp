# Ước lượng mật độ — Bài giảng ôn tập

Tài liệu 70 trang. Bộ 17 bài trọng tâm ôn 45 phút bắt đầu ở trang 50:
10 bài chứng minh KDE/phép chiếu, 3 bài tính toán, 4 câu hỏi lý thuyết.
Mỗi bài có đề bài, điều kiện/công cụ, lời giải từng bước, kết luận và lỗi dễ mắc.
Phần cũ về Histogram/CV, phép chiếu/oracle, Root–Unroot, KDE đa chiều được giữ lại.
Bảng chỉ dẫn có liên kết ở trang đầu; mục lục toàn tài liệu cũng có liên kết.
Các bài là bài luyện theo chủ đề, không phải đề thi chính thức.

## Biên dịch
Giải nén tất cả file vào cùng thư mục. Cần XeLaTeX, Latin Modern Roman và Latin Modern Math.
File chính nạp chuong2_on_tap_45_phut.tex; không biên dịch file bổ sung riêng.

    latexmk -xelatex -interaction=nonstopmode -halt-on-error test_loi_giai_mo_rong.tex

## Kiểm tra đáp số và tạo hình
Python cần numpy, scipy, matplotlib.

    python test_mo_rong_verify.py

Kết quả số lưu trong test_mo_rong_kiem_tra.json. Ngoài các kiểm tra ban đầu,
bộ mới kiểm tra R(f''), tương phản, Pythagoras, D nguyên, chuẩn hóa phản xạ
và LOOCV Gaussian qua cách tính độc lập. Script cũng tạo lại file hình.

## Bố cục đề bài và lời giải
Phần giải đề tổng hợp được tách thành năm bài độc lập, mỗi bài nhắc lại đầy đủ
dữ kiện và yêu cầu trước phần Lời giải. Các mục bài tập cũ cũng có đề bài riêng;
những phần hỏi lý thuyết dùng Câu hỏi và Trả lời.

## Các bài mở rộng về rủi ro
Mở rộng trực tiếp các bài đang có, giữ nguyên mã bài:
- Bài 1.4 (trang 52): MISE chính xác, khai triển theo L2, tối ưu AMISE.
- Bài 2.2 (trang 56): tương phản và độ lạc quan do khớp mẫu.
- Bài 2.3 (trang 57): Pythagoras và tái cấu trúc Bias–Variance;
  lời giải tái cấu trúc ở trang 58.
- Bài II.3 (trang 62): bandwidth tham chiếu chuẩn và AMISE nhỏ nhất.
- Bài III.3 (trang 65): hiệu chỉnh 2V_D, ước lượng phương sai từ mẫu và oracle.
- Bài III.4 (trang 67): chứng minh CV không chệch với h cố định.

Mỗi đề chia ý (a), (b), ... và có lời giải tương ứng. Các kiểm tra mới tính
kỳ vọng chính xác trên mọi số đếm histogram hai ô với n=5 và đối chiếu
kỳ vọng CV với MISE chuẩn bằng tích phân số, không dùng Monte Carlo.
Kết quả nằm trong mục RiskReformulation của test_mo_rong_kiem_tra.json.
